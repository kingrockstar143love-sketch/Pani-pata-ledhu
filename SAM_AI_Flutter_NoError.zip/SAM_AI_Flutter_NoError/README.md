# SAM.AI Flutter project

## Project contents
This archive contains the Flutter source code and a GitHub Actions workflow.

## Extracting
Extract the ZIP once. It creates a folder named `SAM_AI_Flutter_NoError`.
Open that folder; `pubspec.yaml` must be directly inside it.

## Build using GitHub Actions
1. Upload this ZIP to the root of your GitHub repository with the exact name `SAM_AI_Flutter_NoError.zip`.
2. Add the workflow file `.github/workflows/android.yml` to the repository root (the same file is included in this project).
3. Commit the files.
4. Open Actions and run **SAM.AI Android APK Build**.
5. Download the `SAM-AI-APK` artifact after the run succeeds.

## Scope
This is a starter dashboard UI. Real sign-in, AI video processing, YouTube OAuth/upload, and analytics need backend services and API credentials.

## Verification
This environment does not have the Flutter SDK installed, so a local `flutter analyze` or APK build could not be run. GitHub Actions is configured to perform analysis, tests, and the Android build.
