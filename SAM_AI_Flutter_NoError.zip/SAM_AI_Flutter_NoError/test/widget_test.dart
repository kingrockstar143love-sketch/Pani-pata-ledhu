import 'package:flutter_test/flutter_test.dart';
import 'package:sam_ai/main.dart';

void main() {
  testWidgets('SAM.AI dashboard loads', (WidgetTester tester) async {
    await tester.pumpWidget(const SamAiApp());

    expect(find.text('Create amazing videos'), findsOneWidget);
    expect(find.text('AI Video Creator'), findsOneWidget);
    expect(find.text('My Videos'), findsOneWidget);
  });
}
