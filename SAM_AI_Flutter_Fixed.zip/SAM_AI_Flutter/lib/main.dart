import 'package:flutter/material.dart';

void main() {
  runApp(const SamAiApp());
}

class SamAiApp extends StatelessWidget {
  const SamAiApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'SAM.AI',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF090B16),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF8B5CF6),
          brightness: Brightness.dark,
        ),
        useMaterial3: true,
      ),
      home: const DashboardScreen(),
    );
  }
}

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  static const Color purple = Color(0xFF8B5CF6);
  static const Color pink = Color(0xFFEC4899);
  static const Color panel = Color(0xFF15182A);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        title: const Row(
          children: [
            Icon(Icons.play_circle_fill, color: purple, size: 30),
            SizedBox(width: 8),
            Text('SAM.AI', style: TextStyle(fontWeight: FontWeight.bold)),
          ],
        ),
        actions: const [
          Padding(
            padding: EdgeInsets.only(right: 16),
            child: Icon(Icons.account_circle_outlined, size: 28),
          ),
        ],
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(18),
          children: [
            const Text(
              'Create amazing videos',
              style: TextStyle(fontSize: 27, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            Text(
              'Turn your long videos into shareable Shorts.',
              style: TextStyle(color: Colors.white.withValues(alpha: 0.7)),
            ),
            const SizedBox(height: 22),
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(22),
                gradient: const LinearGradient(
                  colors: [Color(0xFF39236D), Color(0xFF17234B), Color(0xFF351B43)],
                ),
              ),
              child: const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Icon(Icons.auto_fix_high, size: 34, color: Colors.white),
                  SizedBox(height: 14),
                  Text(
                    'AI Video Creator',
                    style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 6),
                  Text('Upload a video and prepare short-form clips.'),
                  SizedBox(height: 16),
                  Text(
                    'Starter interface',
                    style: TextStyle(color: Colors.white70, fontSize: 12),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 22),
            const Text(
              'Your workspace',
              style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),
            _FeatureTile(
              icon: Icons.video_library_outlined,
              title: 'My Videos',
              subtitle: 'Your imported and processed videos',
              accent: purple,
            ),
            _FeatureTile(
              icon: Icons.content_cut,
              title: 'AI Clip Editor',
              subtitle: 'Create and edit short clips',
              accent: pink,
            ),
            _FeatureTile(
              icon: Icons.upload_rounded,
              title: 'YouTube Upload',
              subtitle: 'Connect a YouTube account to publish',
              accent: Colors.lightBlueAccent,
            ),
            _FeatureTile(
              icon: Icons.analytics_outlined,
              title: 'Analytics',
              subtitle: 'View performance of published videos',
              accent: Colors.amber,
            ),
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: panel,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: Colors.white12),
              ),
              child: const Text(
                'Note: This is a starter UI. AI processing, sign-in, YouTube '
                'OAuth/upload, and live analytics still need backend/API setup.',
                style: TextStyle(color: Colors.white70, height: 1.45),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _FeatureTile extends StatelessWidget {
  const _FeatureTile({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.accent,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final Color accent;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        color: DashboardScreen.panel,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white10),
      ),
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: accent.withValues(alpha: 0.16),
          child: Icon(icon, color: accent),
        ),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
        subtitle: Text(subtitle),
        trailing: const Icon(Icons.chevron_right),
        onTap: () {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('This feature is not configured in the starter app yet.'),
            ),
          );
        },
      ),
    );
  }
}
