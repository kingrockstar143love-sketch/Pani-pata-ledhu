# SAM.AI – Flutter starter

A dark-themed Flutter starter interface for an AI video creator.

## Build locally
1. Install Flutter stable.
2. Run `flutter pub get`.
3. Run `flutter analyze`.
4. Run `flutter test`.
5. Run `flutter build apk --release`.

## GitHub Actions
The workflow at `.github/workflows/android.yml` runs analysis, tests, and builds a release APK. Open the repository's **Actions** tab, select **SAM.AI Android APK Build**, and run it manually. Download the `SAM-AI-APK` artifact after a successful run.

## Important scope note
This starter currently contains the dashboard UI only. Real authentication, AI video processing, YouTube OAuth/upload, and live analytics require backend services and API configuration.
